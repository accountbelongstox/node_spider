'use strict';

class Page {

    async openPage(url, options = {}) {
        let {
            loadJQuery = false,
            callback = null,
            wait = -1,
            notWait = false,
            width = null,
            height = null,
            headless = null,
            mobile = false,
            openDevTools = false,
            driverType = 'chrome',
            disableGPU = false,
        } = options;

        if (this.isExistsDriver() !== false) {
            this.switchToPage(url, loadJQuery);
            return true;
        }

        if (wait === 0 || notWait) {
            await this.sleep(100);
        } else {
            notWait = false;
        }

        this.driver = await this.getDriver({
            notWait,
            width,
            height,
            headless,
            mobile,
            openDevtools: openDevTools, // 如果在其他地方使用 openDevTools 作为参数名，注意这里的调整
            proxy: false, // 如果需要代理，可以在这里传递代理相关的信息
            driverType,
            disableGpu: disableGPU, // 如果在其他地方使用 disableGPU 作为参数名，注意这里的调整
        });

        console.log(this.driver);

        if (wait > 0) {
            this.driver.setDefaultNavigationTimeout(wait);
            this.driver.setDefaultTimeout(wait);
        }

        console.dir(this.driver)
        const currentUrl = await this.driver.url();
        if (this.__browsermob_proxy) {
            this.proxy.newHar(url, {
                captureHeaders: true,
                captureContent: true,
            });
        }

        if (currentUrl === 'about:blank') {
            try {
                await this.driver.goto(url);
            } catch (error) {
                console.error(`Timed out receiving message from renderer: ${wait}`);
            }
        } else {
            console.log(`Switching to "${url}"`);
            this.switchToPage(url, loadJQuery);
        }

        if (callback !== null) {
            callback(this.driver);
        } else {
            return this.driver;
        }
    }

    async switchTo(urlOrIndex, loadJQuery = false) {
        const driver = this.getDriver();
        const windowHandles = await driver.pages();
        const lenDrivers = windowHandles.length;

        if (typeof urlOrIndex === 'number') {
            const index = urlOrIndex;
            if (index >= lenDrivers) {
                driver.switchToPage(windowHandles[lenDrivers - 1]);
            } else {
                driver.switchToPage(windowHandles[index]);
            }
        } else {
            const url = urlOrIndex;
            let urlExists = false;
            const urlEq = url.split('?')[0].split('#')[0];

            for (const page of windowHandles) {
                driver.switchToPage(page);
                await this.sleep(500); // 0.5秒

                const currentUrl = await page.url();
                const currentUrlEq = currentUrl.split('?')[0].split('#')[0];

                if (currentUrlEq === urlEq) {
                    urlExists = true;
                    console.log(`initDriver found URL is ${currentUrl}`);
                    break;
                }
            }

            if (!urlExists) {
                const js = `window.open('${url}','_blank');`;
                await page.evaluate(js);
                console.log(`initDriver opened a new window for URL: ${url}`);
                const lenDrivers = (await driver.pages()).length;
                driver.switchToPage(windowHandles[lenDrivers - 1]);
                if (loadJQuery) await this.loadJQueryWait();
            } else {
                await page.reload();
                console.log(`initDriver URL already exists for ${url}, refreshed.`);
                await this.sleep(500); // 0.5秒
            }
        }
    }

    async getCurrentWindowHandleIndex(driver) {
        const currentWindowHandle = await driver.getWindowHandle();
        const windowHandles = await driver.getAllWindowHandles();
        for (let i = 0; i < windowHandles.length; i++) {
            if (currentWindowHandle === windowHandles[i]) {
                return i;
            }
        }
        return -1;
    }

    async close(handle = null) {
        await this.closeWindow(handle);
    }

    async closeWindow(handle = null) {
        if (typeof handle === 'string') {
            // TODO
        }
        const driver = this.getDriver();
        await driver.close();
    }

    async closePage(url = null, safe = true) {
        if (typeof url === 'string') {
            this.switchTo(url);
        }
        if (safe === true) {
            const handlength = this.getWindowHandlesLength();
            if (handlength <= 1) {
                return true;
            }
        }
        const jsCode = 'window.close()';
        this.executeJsCode(jsCode);
    }

    async quit() {
        const driver = this.getDriver();
        await driver.quit();
    }
    
    async getCurrentUrl(full = false) {
        const driver = this.getDriver();
        try {
            let currentUrl = await driver.getCurrentUrl();
            if (!full) {
                currentUrl = currentUrl.split('?')[0];
            }
            return currentUrl;
        } catch (e) {
            this.comUtil.printWarn(e);
            return '';
        }
    }

    

    async getWindowHandles() {
        const driver = this.getDriver();
        return await driver.pages(); // Puppeteer's equivalent for getting window handles
    }

    async getWindowHandlesLength() {
        const driver = this.getDriver();
        const windowHandles = await driver.pages();
        return windowHandles.length;
    }
}

Page.toString = () => '[class Page]';
module.exports = Page;

