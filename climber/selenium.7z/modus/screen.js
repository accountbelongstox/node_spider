'use strict';

class Screen {

    async screenshotOfWebpage(selector = null, filePath = null) {
        const driver = this.getDriver();
        filePath = this.getScreenshotSavePath(filePath);
        if (selector !== null) {
            return this.screenshotOfElement(selector, filePath);
        }
        await driver.screenshot({ path: filePath });
        return filePath;
    }

    getScreenshotSavePath(filename = null) {
        if (filename === null) {
            filename = this.comString.randomString(32, false) + '.png';
        }
        const tempDir = this.comConfig.getPublic('downfile/screenshot');
        this.comFile.mkdir(tempDir);
        const filePath = this.comString.dirNormal(path.join(tempDir, filename));
        return filePath;
    }

    async getImage(driver) {
        const img = await driver.$('.code');
        await driver.waitForTimeout(2000); // 2秒
        const location = await img.boundingBox();
        console.log(location);
        const left = location.x;
        const top = location.y;
        const right = left + location.width;
        const bottom = top + location.height;

        const pageSnapObj = await this.getSnap(driver);
        const imageObj = await pageSnapObj.screenshot({
            clip: {
                x: left,
                y: top,
                width: location.width,
                height: location.height
            }
        });
        // imageObj.show(); // 如果需要显示图像，根据需求取消注释
        return imageObj;
    }

    async screenshotOfElement(selector = null, filePath = null) {
        const driver = this.getDriver();
        const element = await this.findElement(selector);
        const location = await element.boundingBox();
        const size = await element.boundingBox();
        filePath = this.getScreenshotSavePath(filePath);

        await driver.screenshot({ path: filePath });

        const x = location.x;
        const y = location.y;
        const width = location.x + size.width;
        const height = location.y + size.height;

        const im = await Jimp.read(filePath);
        im.crop(x, y, width, height);
        const tempImg = this.getScreenshotSavePath();
        await im.writeAsync(tempImg);
        await im.close();

        await fs.promises.unlink(filePath);
        await fs.promises.copyFile(tempImg, filePath);
        await fs.promises.unlink(tempImg);

        return filePath;
    }


    async screenClick(x, y) {
        const driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .build();

        try {
            const url = 'http://www.example.com'; // 请替换成您的目标网页
            await driver.get(url);

            const actions = new Actions(driver);
            actions.move({ x: x, y: y, origin: WebDriver.Button.LEFT }).click().perform();
        } finally {
            await driver.quit();
        }
    }


}

Screen.toString = () => '[class Screen]';
module.exports = Screen;

