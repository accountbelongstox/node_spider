'use strict';
const axios = require('axios');
const puppeteer = require('puppeteer');
const { Builder, By, Key, Capabilities, until, Select, Actions, WebDriver } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');
const edge = require('selenium-webdriver/edge');

class Download {


    getDownloadDir(filename = '') {
        const driverHash = this.comString.md5(this.driverName);
        const uuid = this.loadModule.getUuid();

        if (this.downloadDir === null) {
            const downloadPrefix = 'downfile_';
            const downDir = this.comConfig.getControlTempdir();
            this.comFile.removeOldSubdirs(downDir, downloadPrefix, uuid);

            let downPath = path.join(downDir, `${downloadPrefix}${uuid}_${driverHash}`);
            downPath = this.comString.dirNormal(downPath);
            this.downloadDir = downPath;
            globalDownloadDirs.push(this.downloadDir);
        }

        let downloadDir = this.downloadDir;
        if (filename) {
            downloadDir = path.join(downloadDir, filename);
        }

        return downloadDir;
    }

    getDownloadFilename(fileName) {
        if (this.comHttp.isUrl(fileName)) {
            fileName = path.basename(fileName);
        }
        fileName = fileName.split('?')[0];
        return fileName;
    }
    getDownloadFile(url) {
        const fileName = this.getDownloadFilename(url);
        const findFilename = this.waitDownFile(fileName);

        const result = {
            dynamicUrl: this.isDynamicUrl(url),
            fileName: findFilename,
        };

        return result;
    }

    async waitDownFile(fileName, wait = 0) {
        if (wait > 30) {
            return '';
        }

        for (const downloadDir of globalDownloadDirs) {
            const listDir = fs.readdirSync(downloadDir);

            if (this.isDynamicUrl(fileName)) {
                for (const file of listDir) {
                    const dynamicFile = `${fileName}.`;
                    if (file.startsWith(dynamicFile)) {
                        this.comUtil.printInfo(`down(dynamic) success, ${dynamicFile}, download_dir: ${downloadDir}`);
                        return path.join(downloadDir, file);
                    }
                    if (file.startsWith(fileName)) {
                        this.comUtil.printInfo(`down(dynamic) success, ${fileName}, download_dir: ${downloadDir}`);
                        return path.join(downloadDir, file);
                    }
                }
            } else {
                if (listDir.includes(fileName)) {
                    this.comUtil.printInfo(`down success, ${fileName}, download_dir: ${downloadDir}`);
                    return path.join(downloadDir, fileName);
                }
            }
        }

        wait += 1;
        await this.sleep(1000);
        return this.waitDownFile(fileName, wait);
    }

    setDownloadDir(downloadDir) {
        this.downloadDir = downloadDir;
        return this.downloadDir;
    }

    async downFile(url, save = true) {
        const file_name = this.getDownloadFilename(url);
        const is_dynamic_url = this.isDynamicUrl(file_name);

        const download = {
            url,
            dynamic_url: is_dynamic_url,
        };

        if (is_dynamic_url) {
            await this.isComplete(url);
            const save_filename = await this.screenshotOfElement(`[src="${url}"]`);
            download.save_filename = save_filename;
        } else {
            const property = {
                href: url,
                download: url,
            };
            this.createDownloadLink(url, property);
            const save_filename = await this.getDownloadFile(url);
            const handle_len = await this.getWindowsHandlesLength();
            await this.switchTo(handle_len - 1);
            await this.sleep(500);
            download.save_filename = save_filename.file_name;
        }

        return download;
    }

    async downFileInline(url) {
        if (!this.downJsCode) {
            const jsfile = this.comConfig.getLibs('selenium_down.js'); // 请替换成适当的路径
            const jscode = await this.comFile.readFile(jsfile);
            const remote_url = this.comConfig.getGlobal('remote_url');
            const key = this.comConfig.getGlobal('execute_function_key');
            this.downJsCode = jscode.replace('$$update_url', `${remote_url}/api`);
            this.downJsCode = this.downJsCode.replace('$$key', key);
        }

        const jscode = this.downJsCode.replace('$$down_url', url);
        const downResult = await this.executeJsCode(jscode);

        let save_dir = null;
        const is_dynamic_url = this.isDynamicUrl(url);

        const download = {
            url,
            dynamic_url: is_dynamic_url,
            save_dir,
        };

        if (downResult == null) {
            return download;
        }

        const data = downResult.data;

        if (data.length > 0) {
            const down_status = data[0];
            save_dir = down_status.save_dir;
            download.save_dir = save_dir;
        }

        if (this.comFile.isFile(save_dir)) {
            this.comUtil.printInfo(`down_inline success:\nurl:${url}\nsave_dir:${save_dir}`);
        } else {
            this.comUtil.printWarn(`down_inline err:\nurl:${url}\nis_dynamic_url:${is_dynamic_url}\nsave_dir:${save_dir}`);
        }

        return download;
    }

    async downFileAjax(url, save = true) {
        let result = 'selenium-NotDownloaded'; // 使用let声明而不是重新声明

        const js = `(async () => {
            const url = '${url}';
            if (!document.$download_temp) {
                document.$download_temp = {};
            }
            document.$download_temp[url] = '${result}';
            const response = await axios.get(url, { responseType: 'arraybuffer' });
            document.$download_temp[url] = Buffer.from(response.data).toString('binary');
        })();`;

        await this.executeJsCode(js);

        const returnJs = `return document.$download_temp['${url}']`;
        result = await this.executeJsCode(returnJs); // 移除let，只赋值

        while (result === 'selenium-NotDownloaded') {
            await this.sleep(3000);
            result = await this.executeJsCode(returnJs); // 移除let，只赋值
        }

        const fileName = this.getFileNameFromUrl(url);

        if (save) {
            console.log(result);
            const filePath = this.getDownloadDirectory(fileName);
            fs.writeFileSync(filePath, result, 'binary');
            result = {
                url,
                save_filename: filePath
            };
        }

        return true;
    }
}

Download.toString = () => '[class Download]';
module.exports = Download;

