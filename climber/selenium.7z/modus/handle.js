'use strict';

class Handle {

    async executeJsCode(jsCode) {
        const driver = this.getDriver();
        const result = await driver.executeScript(jsCode);
        return result;
    }

    async performAction(selector, action, value = null) {
        const driver = await new Builder().forBrowser('chrome').build(); // 可以使用其他浏览器

        try {
            const elements = await driver.findElements(By.css(selector));

            for (const element of elements) {
                if (action === 'click') {
                    await element.click();
                } else if (action === 'value') {
                    await element.sendKeys(value);
                } else {
                    // 如果还有其他支持的操作，可以在此处添加
                    console.log('Unsupported action:', action);
                }
            }
        } finally {
            await driver.quit();
        }
    }
    
    async verificationTextClickCode(args, screenshot = false) {
        const hintSelector = args.hint;
        const identificationZoneSelector = args.identification_zone;

        let hintImgPath;
        let identificationZonePath;

        if (screenshot) {
            // 捕获元素的屏幕截图
            hintImgPath = await screenshotOfElement(hintSelector);
            identificationZonePath = await screenshotOfElement(identificationZoneSelector);
        } else {
            const hintImg = await findPropertyWait(hintSelector, 'src');
            hintImgPath = await downloadFile(hintImg);

            const identificationZoneImg = await findPropertyWait(identificationZoneSelector, 'src');
            identificationZonePath = await downloadFile(identificationZoneImg);

            console.log(`hint_img_path: ${hintImgPath}`);
            console.log(`identification_zone_path: ${identificationZonePath}`);
        }

        const clickZone = args.click_zone;
    }

    
    executeJs(js) {
        const jsPath = path.join(__dirname, 'js', js); // 设置 JavaScript 文件的路径
        if (fs.existsSync(jsPath)) {
            // 如果文件存在，执行文件中的 JavaScript
            return executeJsFile(jsPath);
        } else {
            // 否则，执行传入的 JavaScript 代码
            return executeJsCode(js);
        }
    }

    async executeJsAndReturn(jsCode, notWait = false) {
        const tempParameter = '__$temp_$parameter';
        const js = `
            window.${tempParameter} = (async () => {
                ${jsCode}
            })();
        `;

        await executeJsCode(js);

        if (!notWait) {
            await sleep(200); // 等待 200 毫秒
        }

        let result;
        let index = 0;

        while (result === null && index < 75) { // 最多等待 15 秒
            if (!notWait) {
                await sleep(200); // 等待 200 毫秒
            }
            console.log(`Waiting for executeJsAndReturn element ${index / 5} seconds return value`);
            result = await executeJsCode(`return window.${tempParameter}`);
            index++;
        }

        return result;
    }

    async executeJsFile(jsFile) {
        const driver = await new Builder().forBrowser('chrome').build();

        try {
            const jsPath = 'path/to/your/js/files/' + jsFile; // 设置为 JavaScript 文件的路径
            if (fs.existsSync(jsPath)) {
                const jsString = fs.readFileSync(jsPath, 'utf8');
                console.log('Execute JavaScript from file:', jsFile);
                console.log('JavaScript content:', jsString.substring(0, 100));

                const result = await driver.executeScript(jsString);
                console.log('JavaScript execution result:', result);
            } else {
                console.error(`JavaScript file not found: ${jsFile}`);
            }
        } catch (error) {
            console.error('Error executing JavaScript file:', error);
        } finally {
            await driver.quit();
        }
    }

    async executeJsCode(jsString) {
        const driver = await new Builder().forBrowser('chrome').build();
        let result = null;

        try {
            result = await driver.executeScript(jsString);
        } catch (err) {
            console.error(err);
        } finally {
            await driver.quit();
        }

        return result;
    }

    async executeJsWait(js, deep = 9) {
        let result = null;
        let index = 0;

        while (result === null && index < deep) {
            result = await executeJsCode(js);
            console.log(`executeJsWait execute to ${js.slice(0, 50)}`);
            await new Promise(resolve => setTimeout(resolve, 1000)); // 等待1秒
            index++;
        }

        return result;
    }

    
    async moveElement(selector, target = {}) {
        const { Builder, By } = require('selenium-webdriver');
        const driver = await new Builder().forBrowser('chrome').build();
        const ele = await driver.findElement(By.css(selector));

        // TODO: 使用 ActionChains(driver) 方法将元素移动到目标坐标 (target)

        // 关闭 WebDriver
        await driver.quit();
    }

    
    async jsFindAttr(selector, attr) {
        const driver = await new Builder().forBrowser('chrome').build();

        const findElementJs = `return document.querySelector('${selector}')['${attr}']`;
        console.log(findElementJs);
        const result = await driver.executeScript(findElementJs);

        // 关闭 WebDriver
        await driver.quit();

        return result;
    }

    async sendKeys(selector, val, simulation = false) {
        if (simulation) {
            // TODO: 调用适当的方法执行模拟键盘输入
        } else {
            await sendKeysJS(selector, val);
        }
    }

    async sendKeysJS(selector, val) {
        const driver = await new Builder().forBrowser('chrome').build();
        // TODO: 聚焦到元素
        const jsCode = `document.querySelector('${selector}').value = '${val}'`;
        await driver.executeScript(jsCode);

        // 关闭 WebDriver
        await driver.quit();
    }

    async explicitPositionElement(selector) {
        const driver = await new Builder().forBrowser('chrome').build();
        const element = await driver.findElement(By.css(selector));

        const browserTitleHeight = 80; // 根据您的实际情况调整标题栏的高度
        const location = await element.getLocation();
        const locationX = location.x;
        const locationY = location.y;
        const windowPosition = await driver.manage().window().getPosition();
        const windowX = windowPosition[0];
        const windowY = windowPosition[1];
        const size = await element.getSize();
        const sizeHeight = size.height / 2 < 1 ? size.height : size.height / 2;
        const sizeWidth = size.width / 2 < 1 ? size.width : size.width / 2;
        const x = windowX + locationX + sizeWidth;
        const y = windowY + browserTitleHeight + locationY + sizeHeight;

        console.log('x:', x, 'y:', y);

        // 关闭 WebDriver
        await driver.quit();
    }

    createSelectorScript(selector, script) {
        return `document.querySelector(\`${selector}\`)${script}`;
    }

    async executeSafeScript(driver, selector, script, alert = true) {
        const js = `
            if (document.querySelector(\`${selector}\`)) {
                ${script}
            }${alert ? ` else {
                console.debug('Selenium failed to execute script, selector ${selector}');
            }` : ''}
        `;

        try {
            await driver.executeScript(js);
        } catch (e) {
            console.error(e);
            if (e.toString().includes('closed')) {
                console.log('Chrome was already closed. Restart the WebDriver.');
            }
        }
    }


    async sendKeysSimulation(driver, selector, val) {
        await focus(driver, selector);
        await driver.actions().sendKeys(val).perform();
        await driver.actions().sendKeys(Key.ENTER).perform();
        await driver.sleep(1000); // 根据需要进行调整等待时间
    }

    async focus(driver, selector) {
        const element = await driver.findElement(By.css(selector));
        await driver.executeScript("arguments[0].focus();", element);
    }

    async click(driver, selector) {
        const element = await driver.findElement(By.css(selector));
        await element.click();
    }

    async remove(driver, selector) {
        // 通过 JavaScript 从 DOM 中移除元素
        const js = `document.querySelector('${selector}').remove();`;
        await driver.executeScript(js);
    }

    async event(driver, selector, event) {
        const js = `if (document.querySelector(\`${selector}\`)) document.querySelector(\`${selector}\`).${event}();`;
        await driver.executeScript(js);
    }

    async setInnerHtml(driver, selector, htmlText) {
        const escapedHtml = htmlText.replace(/`/g, '\\`');
        const js = `document.querySelector(\`${selector}\`).innerHTML = \`${escapedHtml}\`;`;
        await driver.executeScript(js);
    }

    async insertHtmlBefore(driver, selector, html) {
        const js = `document.querySelector(\`${selector}\`).insertAdjacentHTML('beforebegin', \`${html}\`);`;
        await driver.executeScript(js);
    }

    async insertHtmlAfter(driver, selector, html) {
        const js = `document.querySelector(\`${selector}\`).insertAdjacentHTML('afterend', \`${html}\`);`;
        await driver.executeScript(js);
    }

    async insertHtml(driver, selector, html, insertAction) {
        const escapedHtml = html.replace(/`/g, '\\`');
        let js;

        if (insertAction === 'before') {
            js = `document.querySelector(\`${selector}\`).innerHTML += \`${escapedHtml}\`;`;
        } else {
            js = `document.querySelector(\`${selector}\`).innerHTML = \`${escapedHtml}\` + document.querySelector(\`${selector}\`).innerHTML;`;
        }

        await driver.executeScript(js);
    }
    
    async createElement(tagname, property = {}, text = "", action = "", insert = "body") {
        const driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .build();

        try {
            const url = 'http://www.example.com'; // 请替换成您的目标网页
            await driver.get(url);

            let js = `
                (() => {
                    let element = document.createElement("${tagname}");
                    `;

            for (const key in property) {
                if (property.hasOwnProperty(key)) {
                    js += `
                    element.${key} = ${JSON.stringify(property[key])};
                    `;
                }
            }

            if (text !== "") {
                js += `
                    let text = document.createTextNode("${text}");
                    element.appendChild(text);
                    `;
            }

            if (action !== "") {
                js += `
                    element.${action}();
                    `;
            }

            js += `
                    document.querySelector("${insert}").insertAdjacentElement('beforebegin', element);
                })();
            `;

            await driver.executeScript(js);
        } finally {
            await driver.quit();
        }
    }

    async offsetScrollToWindow(selector) {
        const driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .build();

        try {
            const url = 'http://www.example.com'; // 请替换成您的目标网页
            await driver.get(url);

            const js = `
                function getElementTop(el, targetEl) {
                    const parent = el.offsetParent;
                    const top = el.offsetTop;
                    return parent && parent !== targetEl
                        ? getElementTop(parent, targetEl) + top
                        : top;
                }
                return getElementTop(document.querySelector("${selector}"), document.querySelector("body"));
            `;

            const result = await driver.executeScript(js);
            return result;
        } finally {
            await driver.quit();
        }
    }

    async offsetToWindow(selector) {
        const driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .build();

        try {
            const url = 'http://www.example.com'; // 请替换成您的目标网页
            await driver.get(url);

            const js = `
                function getElementTop(el, targetEl) {
                    const parent = el.offsetParent;
                    const top = el.offsetTop;
                    return parent && parent !== targetEl
                        ? getElementTop(parent, targetEl) + top
                        : top;
                }
                return getElementTop(document.querySelector("${selector}"), document.querySelector("body")) - (document.body.scrollTop + document.documentElement.scrollTop);
            `;

            const result = await driver.executeScript(js);
            return result;
        } finally {
            await driver.quit();
        }
    }

    async offsetTop(selector) {
        return this.findAttrByJs(selector, 'offsetTop');
    }

    async offsetLeft(selector) {
        return this.findAttrByJs(selector, 'offsetLeft');
    }

    async scrollIntoView(selector) {
        const jsCode = `document.querySelector("${selector}").scrollIntoView();`;
        await this.executeJsCode(jsCode);
    }

    async scrollToBottom() {
        const jsCode = 'window.scrollTo(0, document.body.scrollHeight);';
        await this.executeJsCode(jsCode);
    }

    async scrollToTop() {
        const jsCode = 'window.scrollTo(0, 0);';
        await this.executeJsCode(jsCode);
    }

    async scrollTo(start, height) {
        const jsCode = `window.scrollTo(${start}, ${height});`;
        await this.executeJsCode(jsCode);
    }


    async slidingElement(selector, x_offset, y_offset) {
        const driver = await new Builder().forBrowser('chrome').build();
        const ele = await driver.findElement(By.css(selector));

        // 模拟滑动操作
        await driver.actions({ bridge: true })
            .move({ origin: ele })
            .press()
            .move({ x: x_offset, y: y_offset })
            .release()
            .perform();

        // 关闭 WebDriver
        await driver.quit();
    }


}

Handle.toString = () => '[class Handle]';
module.exports = Handle;

