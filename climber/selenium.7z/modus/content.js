'use strict';

class Content {


    async findHtmlWait() {
        const driver = this.getDriver();
        const outerHTML = await driver.executeScript("return document.documentElement.outerHTML");
        if (outerHTML != null && outerHTML.length > 0) {
            return outerHTML;
        } else {
            return this.findHtmlWait();
        }
    }

    async getHtml() {
        const outerHTML = await this.executeJsCode("return document.documentElement.outerHTML");
        return outerHTML;
    }


    async getDocumentLinks() {
        const jsCode = `
            let hrefs = [];
            let links = document.links;
            for (let i = 0; i < links.length; i++) {
                let e = links[i];
                hrefs.push({
                    index: i,
                    href: e.href,
                    base_url: e.baseURI,
                    host: e.host,
                    hostname: e.hostname,
                    inner_text: e.innerText,
                    origin: e.origin,
                    pathname: e.pathname,
                    protocol: e.protocol
                });
            }
            return hrefs;
        `;
        const links = await this.executeJsAndReturn(jsCode);
        return links;
    }

    async getDocumentResource(tagname = 'img') {
        const jsCode = `
            let res = [];
            let tags = document.querySelectorAll('${tagname}');
            for (let i = 0; i < tags.length; i++) {
                let e = tags[i];
                let src = null;
                if (e.dataset) {
                    src = e.dataset.src;
                }
                res.push({
                    index: i,
                    href: e.href,
                    src: src,
                    current_src: e.currentSrc,
                    dataset: e.dataset,
                    nodeName: e.nodeName,
                    base_url: e.baseURI,
                    host: e.host,
                    hostname: e.hostname,
                    inner_text: e.innerText,
                    origin: e.origin,
                    pathname: e.pathname,
                    protocol: e.protocol,
                    alt: e.alt
                });
            }
            return res;
        `;
        const res = await this.executeJsAndReturn(jsCode);
        return res;
    }

    async setHtml(content, selector = null) {
        const driver = this.getDriver();
        content = this.comString.encode(content);
        let js;
        if (!selector) {
            js = `document.documentElement.innerHTML = \`${content}\``;
        } else {
            js = `document.querySelector('${selector}').innerHTML = \`${content}\``;
        }
        await driver.executeScript(js);
    }

    isElement(element) {
        if (element.constructor.name === 'WebElement') {
            return true;
        } else if (typeof element === 'string') {
            const elements = this.executeJsWait(`return document.querySelectorAll('${element}')`);
            return elements.length > 0;
        } else {
            return false;
        }
    }

    elementExist(element) {
        return this.isElement(element);
    }

    findElement(selector, isBeautifulSoup = false, driver = null) {
        const elements = this.findElements(selector, isBeautifulSoup, driver);
        return elements.length > 0 ? elements[0] : null;
    }

    async findElementByJs(selector) {
        const js = `return document.querySelector(\`${selector}\`)`;
        return await this.executeJsCode(js);
    }

    async findElementByJsWait(selector, deep = 30) {
        const js = `return document.querySelector(\`${selector}\`)`;
        let ele = await this.executeJsCode(js);
        let setpin = 2;
        let index = 0;
        while (!ele && setpin * index < deep) {
            const waitSecond = index / setpin;
            if (waitSecond > 5) {
                console.log(`Waiting ${selector} ${index / setpin} seconds js:${js}`);
            }
            await this.sleep(500);
            ele = await this.executeJsCode(js);
            index++;
        }
        return ele;
    }

    async findElementsWait(selector, deep = 0, driver = null) {
        if (deep === 3 && deep !== false) {
            return null;
        }
        try {
            const elements = await this.findElements(selector, driver);
            if (elements !== null) {
                return elements;
            }
            throw new NoSuchElementException();
        } catch (error) {
            deep++;
            await this.sleep(500);
            return await this.findElementsWait(selector, deep, driver);
        }
    }

    
    async findElementWait(selector, deep = 0) {
        if (deep === 3 * 3 && deep !== false) {
            return null;
        }
        try {
            const ele = await this.findElement(selector);
            if (ele !== null) {
                return ele;
            }
            throw new NoSuchElementException();
        } catch (error) {
            deep++;
            await this.sleep(1000);
            return await this.findElementWait(selector, deep);
        }
    }

    async findContent(selector) {
        const ele = await this.findElementWait(selector);
        try {
            let text = await ele.getText();
            text = text.replace("0", "");
            if (text.length > 0) {
                return text;
            }
        } catch (error) {
            return null;
        }
    }

    async findContentWait(selector, deep = 0) {
        if (deep === 3) {
            console.log(`findContentWait deep ${deep}`);
            return null;
        }
        console.log(`findContentWait ${selector}`);
        const text = await this.findContent(selector);
        if (text !== null) {
            return text;
        } else {
            deep++;
            await this.sleep(1000);
            return await this.findContentWait(selector, deep);
        }
    }

    async findElements(selector, isBeautifulSoup = false, driver = null) {
        const st = this.selectorParse(selector);
        let elements = [];
        if (st === "css") {
            elements = await this.findElementsByCss(selector, isBeautifulSoup, driver);
        } else if (st === "xpath") {
            elements = await this.findElementsByXpath(selector, isBeautifulSoup, driver);
        } else if (st === "id") {
            elements = await this.findElementsById(selector, isBeautifulSoup, driver);
        } else if (st === "tag") {
            elements = await this.findElementsByTagName(selector, isBeautifulSoup, driver);
        }

        if (!Array.isArray(elements)) {
            elements = [elements];
        }

        return elements;
    }
    selectorParse(selector) {
        // 根据你的实际需求实现 selectorParse 方法
        // 返回 "css", "xpath", "id", "tag" 或其他值
    }
    async findElementsByCss(selector, isBeautifulSoup, driver) {
        // 根据你的实际需求实现 findElementsByCss 方法
        // 返回元素数组
    }
    async findElementsByXpath(selector, isBeautifulSoup, driver) {
        // 根据你的实际需求实现 findElementsByXpath 方法
        // 返回元素数组
    }
    async findElementsById(selector, isBeautifulSoup, driver) {
        // 根据你的实际需求实现 findElementsById 方法
        // 返回元素数组
    }
    async findElementsByTagName(selector, isBeautifulSoup, driver) {
        // 根据你的实际需求实现 findElementsByTagName 方法
        // 返回元素数组
    }

    async findHtmlByJsWait(selector, deep = null, noWait = false) {
        let js;
        if (selector[0] === '/') {
            js = `return document.evaluate('${selector}', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null) ? document.evaluate('${selector}', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.outerHTML : null`;
        } else {
            js = `return document.querySelector('${selector}') ? document.querySelector('${selector}').outerHTML : null`;
        }

        if (noWait) {
            return this.executeJs(js);
        }

        return this.executeJsWait(js, deep);
    }

    findHtmlByJs(selector) {
        return this.findHtmlByJsWait(selector, { noWait: true });
    }
    async executeJs(js) {
        // 根据你的实际需求执行 JavaScript 代码并返回结果
    }
    async executeJsWait(js, deep) {
        // 根据你的实际需求执行 JavaScript 代码，支持等待和重试
    }

    async findElementValueByJsWait(selector, noWait = false, deep = 30, textNot = null, info = false) {
        let js;
        if (selector[0] === '/') {
            js = `return document.evaluate(\`${selector}\`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null) ? document.evaluate(\`${selector}\`, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.innerHTML : null`;
        } else {
            js = `return document.querySelector(\`${selector}\`) ? document.querySelector(\`${selector}\`).textContent : null`;
        }

        if (noWait) {
            return this.executeJs(js);
        }

        if (!deep) {
            deep = 99999;
        }

        this.findElementByJsWait(selector, { deep });

        const setpin = 2;
        let val = this.executeJsCode(js);
        let index = 0;

        while (val === textNot && (index / setpin) < deep) {
            if (info) {
                console.log(`Waiting-selector[fun:findElementValueByJsWait]: (${selector}) \n\tvalue:${val}, (value-not: ${textNot})\n\twaited: ${index / setpin} second, deep: ${deep}`);
            }

            await this.sleep(500); // 500 milliseconds
            val = this.executeJsCode(js);
            index++;
        }

        return val;
    }

    async findValueByJs(selector) {
        return this.findElementValueByJsWait(selector, { noWait: true });
    }

    async findValueByJsWait(selector, textNot = null, deep = 10, info = false) {
        return this.findElementValueByJsWait(selector, { textNot, deep, info });
    }

    async findAttrByJs(selector, attr) {
        const js = `return document.querySelector(\`${selector}\`) ? document.querySelector(\`${selector}\`).${attr} : null`;
        return this.executeJsCode(js);
    }

    async findTextContentByJsWait(selector, textNot = null, deep = 10, info = false) {
        return this.findElementValueByJsWait(selector, { textNot, deep, info });
    }

    async findTextContentByJs(selector) {
        return this.findElementValueByJsWait(selector, { noWait: true });
    }

    async findTextContentList(selector, {
        childSelector = "",
        nextSibling = "",
        htmlSplit = false,
        deduplication = false,
        attribute = "innerHTML",
        wait = false
    } = {}) {
        const clearElement = ["", " ", "|", ", ", ",", '"'];

        if (childSelector) {
            childSelector = `.querySelector(\`${childSelector}\`)`;
        }

        let selectorSentence;
        if (nextSibling) {
            selectorSentence = `document.querySelector(\`${selector}\`)${nextSibling};`;
        } else {
            selectorSentence = `document.querySelectorAll(\`${selector}\`);`;
        }

        let htmlSplitCode = "";
        if (htmlSplit) {
            htmlSplitCode = ".split(/<.+?>/)";
        }

        let waitWhileCode = "";
        if (wait) {
            waitWhileCode = `
                let index = 0;
                while (dfDiv == null || dfDiv.length === 0) {
                    console.log(index);
                    dfDiv = getDfDiv();
                    index++;
                }
            `;
        }

        const js = `
            getFindTextContentList() {
                const contentList = [];
                let dfDiv;
                const getDfDiv = () => {
                    try {
                        dfDiv = ${selectorSentence};
                        return dfDiv;
                    } catch (e) {
                        console.log(e);
                        return [];
                    }
                }
                dfDiv = getDfDiv();
                ${waitWhileCode}
                if (!dfDiv) {
                    return [];
                }
                for (let i = 0; i < dfDiv.length; i++) {
                    let e;
                    try {
                        e = dfDiv[i]${childSelector}.${attribute}${htmlSplitCode};
                        contentList.push(e);
                    } catch (e) {
                        return [];
                    }
                }
                return contentList;
            }
            return getFindTextContentList();
        `;

        let textContentList = await this.executeJsAndReturn(js);
        textContentList = this.comUtil.clearValue(textContentList, clearElement);
        if (textContentList === null) {
            return [];
        }
        for (const content of textContentList) {
            this.comUtil.clearValue(content, clearElement);
        }
        if (deduplication) {
            textContentList = this.comUtil.deduplication(textContentList);
        }
        return textContentList;
    }

    async findElementsValueByJsWait(selector, url) {
        const cont = await this.statisticalElementsWait(selector, { url });
        const texts = [];
        for (let el = 0; el < cont; el++) {
            const js = `return document.querySelectorAll('${selector}') ? document.querySelectorAll('${selector}')[${el}].textContent : null`;
            const text = await this.executeJsWait(js);
            texts.push(text);
        }
        return texts;
    }

    async findProperty(selector, attrVal, url) {
        console.log(`findProperty: ${selector} Get ${attrVal}`);
        const cont = await this.statisticalElements(selector, { url });
        const texts = [];
        for (let el = 0; el < cont; el++) {
            const js = `return document.querySelectorAll('${selector}') ? document.querySelectorAll('${selector}')[${el}]['${attrVal}'] : null`;
            const text = await this.executeJavascript(js);
            texts.push(text);
        }
        return texts;
    }

    async findPropertyWait(selector, attrVal, url) {
        console.log(`findPropertyWait: ${selector} Get ${attrVal}`);
        const cont = await this.statisticalElementsWait(selector, { url });
        const texts = [];
        for (let el = 0; el < cont; el++) {
            const js = `return document.querySelectorAll('${selector}') ? document.querySelectorAll('${selector}')[${el}]['${attrVal}'] : null`;
            const text = await this.executeJsWait(js);
            texts.push(text);
        }
        return texts;
    }

    async statisticalElements(selector) {
        const js = `return document.querySelectorAll('${selector}') ? document.querySelectorAll('${selector}').length.toString() : '0'`;
        const cont = await this.executeJsWait(js);
        return parseInt(cont, 10);
    }

    async statisticalElementsWait(selector, num = 0, url = null) {
        const cont = await this.statisticalElements(selector);

        if (num === 2 && url !== null) {
            // 如果连续查找不到元素，有可能浏览器被操作，查找当前URL是否还存在，不存在则打开
            await this.openUrlAsNewWindow(url);
            await this.sleep(2000); // 等待 2 秒
        }

        if (cont > 0 || num === 3) {
            console.log(`findElementsCountWait cont: ${cont}`);
            return cont;
        } else {
            await this.sleep(1000); // 等待 1 秒
            const currentUrl = await this.getCurrentUrl();
            console.log(`findElementsCountWait url ${currentUrl} as cont: ${cont}`);
            return this.statisticalElementsWait(selector, num + 1);
        }
    }

    async secondFindElements(ele, selector) {
        const st = selectorParse(selector);
        console.log(`secondFindElements ${selector}`);
        let elements = null;

        if (st === "css") {
            elements = await ele.findElements(By.css(selector));
        } else if (st === "xpath") {
            elements = await ele.findElements(By.xpath(selector));
        } else if (st === "id") {
            selector = selector.substring(1); // 移除首个字符
            elements = await ele.findElement(By.id(selector));
        } else if (st === "tag") {
            const tagSelector = selector.replace("<", "").replace(">", "");
            elements = await ele.findElements(By.tagName(tagSelector));
        } else if (st === "text") {
            elements = await ele.findElements(By.linkText(selector));
        }

        return elements;
    }

    selectorParse(selector) {
        selector = selector.trim().toLowerCase();
        const HTML_TABS = ["<a>", "<abbr>", "<acronym>", "<abbr>", "<address>", "<applet>", "<embed>", "<object>", "<area>", "<article>", "<aside>", "<audio>", "<b>", "<base>", "<basefont>", "<bdi>", "<bdo>", "<big>", "<blockquote>", "<body>", "<br>", "<button>", "<canvas>", "<caption>", "<center>", "<cite>", "<code>", "<col>", "<colgroup>", "<command>", "<data>", "<datalist>", "<dd>", "<del>", "<details>", "<dir>", "<div>", "<dfn>", "<dialog>", "<dl>", "<dt>", "<em>", "<embed>", "<fieldset>", "<figcaption>", "<figure>", "<font>", "<footer>", "<form>", "<frame>", "<frameset>", "<h1>", "<h2>", "<h3>", "<h4>", "<h5>", "<h6>", "<head>", "<header>", "<hr>", "<html>", "<i>", "<iframe>", "<img>", "<input>", "<ins>", "<isindex>", "<kbd>", "<keygen>", "<label>", "<legend>", "<li>", "<link>", "<main>", "<map>", "<mark>", "<menu>", "<menuitem>", "<meta>", "<meter>", "<nav>", "<noframes>", "<noscript>", "<object>", "<ol>", "<optgroup>", "<option>", "<output>", "<p>", "<param>", "<pre>", "<progress>", "<q>", "<rp>", "<rt>", "<ruby>", "<s>", "<samp>", "<script>", "<section>", "<select>", "<small>", "<source>", "<span>", "<strike>", "<del>", "<s>", "<strong>", "<style>", "<sub>", "<summary>", "<details>", "<sup>", "<svg>", "<table>", "<tbody>", "<td>", "<template>", "<textarea>", "<tfoot>", "<th>", "<thead>", "<time>", "<title>", "<tr>", "<track>", "<tt>", "<u>", "<ul>", "<var>", "<video>", "<wbr>", "<xmp>"];
        const first_alphabet = selector[0];

        if (first_alphabet === "/") {
            return "xpath";
        } else if (first_alphabet === "#") {
            return "id";
        } else if (HTML_TABS.includes(`<${selector}>`) || HTML_TABS.includes(selector)) {
            return "tag";
        } else if (first_alphabet === "." || selector.includes(" ") || selector.includes(":") || selector.includes("[") || selector.includes(">")) {
            return "css";
        } else {
            return "text";
        }
    }

    async findElementsByTagname(selector, isBeautifulsoup, driver) {
        if (!driver) {
            driver = await new Builder().forBrowser('chrome').build(); // 可以使用其他浏览器
        }
        selector = selector.replace("<", "").replace(">", "");

        if (isBeautifulsoup) {
            const html = await driver.getPageSource();
            const eles = html.match(new RegExp(`<${selector}>`, 'g')); // 匹配所有出现的标签
            return eles;
        } else {
            const elements = await driver.findElements(By.tagName(selector));
            return elements;
        }
    }

    async findElementsByID(selector, isBeautifulsoup, driver) {
        if (!driver) {
            driver = await new Builder().forBrowser('chrome').build(); // 可以使用其他浏览器
        }
        selector = selector.substring(1); // 去掉 '#'

        if (isBeautifulsoup) {
            const html = await driver.getPageSource();
            const match = html.match(new RegExp(`id="${selector}"`, 'g')); // 匹配所有出现的 id 属性
            const ele = match ? [selector] : [];
            return ele;
        } else {
            const element = await driver.findElement(By.id(selector));
            return [element];
        }
    }

    async findElementsByCss(selector, isBeautifulsoup, driver) {
        if (!driver) {
            driver = await new Builder().forBrowser('chrome').build(); // 可以使用其他浏览器
        }

        if (isBeautifulsoup) {
            const html = await driver.getPageSource();
            const cheerio = require('cheerio');
            const $ = cheerio.load(html);
            const elements = $(selector);
            return elements.toArray().map((element) => element.outerHTML);
        } else {
            const elements = await driver.findElements(By.css(selector));
            return elements;
        }
    }

    async findElementsByXPath(selector, isBeautifulsoup, driver) {
        if (!driver) {
            driver = await new Builder().forBrowser('chrome').build(); // 可以使用其他浏览器
        }

        if (isBeautifulsoup) {
            const html = await driver.getPageSource();
            const xpath = require('xpath');
            const dom = require('xmldom').DOMParser;
            const doc = new dom().parseFromString(html);
            const elements = xpath.select(selector, doc);
            return elements;
        } else {
            const element = await driver.findElement(By.xpath(selector));
            return [element];
        }
    }

    async findElementByText(selector, searchText) {
        const driver = await new Builder().forBrowser('chrome').build(); // 可以使用其他浏览器

        try {
            const elements = await driver.findElements(By.css(selector));

            for (const element of elements) {
                const text = await element.getText();
                if (text === searchText) {
                    return element;
                }
            }
        } finally {
            await driver.quit();
        }

        return null; // 如果找不到匹配的元素
    }
    

    async getHtml() {
        const url = 'http://www.baidu.com';

        this.options.setLoggingPrefs({ 'performance': 'ALL' });

        const driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .build();

        try {
            await driver.get(url);

            // Wait for some time to allow the performance logs to populate
            await driver.sleep(2000);

            const performanceLogs = await driver.manage().logs().get('performance');
            for (const entry of performanceLogs) {
                const params = JSON.parse(entry.message).message;
                if (params.request) {
                    console.log('Request:', params.request);
                }
                if (params.response) {
                    console.log('Response:', params.response);
                }
            }
        } finally {
            await driver.quit();
        }
    }

    async getLog() {
        // Set up a proxy server for performance logs
        const server = new Server('/path/to/chromedriver');
        server.start();

        this.options.setLoggingPrefs({ 'performance': 'ALL' });
        this.options.setProxy(server.getProxy());

        const driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .build();

        try {
            const url = 'http://www.example.com';
            await driver.get(url);

            // Wait for some time to allow the performance logs to populate
            await driver.sleep(2000);

            const logs = await driver.manage().logs().get('performance');
            logs.forEach(entry => {
                console.log('Performance log entry:');
                console.log(entry.message);
            });

            return logs;
        } finally {
            await driver.quit();
            server.stop();
        }
    }

    async waitSelect(selector, deep = 0) {
        const driver = await new Builder().forBrowser('chrome').build();
        try {
            await driver.get('http://www.example.com');
            await driver.wait(until.elementLocated(By.css(selector), deep));
            const ele = await driver.findElement(By.css(selector));
            await driver.wait(async () => {
                const selectedOptions = await ele.findElements(By.css('option:checked'));
                return selectedOptions.length > 0;
            }, deep * 1000, `Element ${selector} is not selected after ${deep} seconds.`);
            return ele;
        } finally {
            await driver.quit();
        }
    }

    async selectWait(selector, value) {
        await this.select(selector, value);
    }

    async select(selector, value) {
        const driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .build();

        try {
            const url = 'http://www.example.com';
            await driver.get(url);

            const ele = await this.waitSelect(driver, selector);
            const select = new Select(ele);
            select.selectByValue(value);
        } finally {
            await driver.quit();
        }
    }

    async waitSelectByJs(selector, deep = 30) {
        const driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .build();

        try {
            const url = 'http://www.example.com';
            await driver.get(url);

            let result = await this.executeJs(driver, selector);
            let index = 0;

            while (!result && index < deep) {
                result = await this.executeJs(driver, selector);
                index += 1;
                console.log(`Wait: ${selector}`);
                await new Promise(resolve => setTimeout(resolve, 1000)); // 等待 1 秒
            }

            return result;
        } finally {
            await driver.quit();
        }
    }

    
    async elementHeight(selector) {
        return this.findAttrByJs(selector, 'getBoundingClientRect().height');
    }

    async elementWidth(selector) {
        return this.findAttrByJs(selector, 'getBoundingClientRect().width');
    }
    

    async getHtmlIps(waitElement, textNot, info, html) {
        let isSeleniumScratchHtml = false;

        if (!html) {
            isSeleniumScratchHtml = true;
            html = await this.getHtml();
        }

        if (html.includes("page can’t be found") || html.includes('No webpage was found for the web address')) {
            return [];
        }

        if (waitElement && isSeleniumScratchHtml) {
            await this.findTextContentByJsWait(waitElement, textNot, false, info);
        }

        const ipPattern = /([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/g;
        if (isSeleniumScratchHtml) {
            html = await this.getHtml();
        }

        const ips = html.match(ipPattern) || [];
        const filteredIps = [];
        const excludeIps = [
            "223.104.112.241",
            "183.232.231.172"
        ];

        for (const ip of ips) {
            if (this.isPublicIp(ip) && !excludeIps.includes(ip)) {
                filteredIps.push(ip);
            }
        }

        return filteredIps;
    }
    

    async searchContent(searchContent, searchSelector, submitSelector) {
        const driver = await new Builder().forBrowser('chrome').build(); // 可以使用其他浏览器

        try {
            await driver.get('https://your-website-url'); // 替换成您要搜索的网站 URL

            const searchElement = await driver.findElement(By.css(searchSelector));
            await searchElement.sendKeys(searchContent);

            const submitElement = await driver.findElement(By.css(submitSelector));
            await submitElement.click();

            const currentUrl = await driver.getCurrentUrl();
            return currentUrl;
        } finally {
            await driver.quit();
        }
    }

}

Content.toString = () => '[class Content]';
module.exports = Content;

