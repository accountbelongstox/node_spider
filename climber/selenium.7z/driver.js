'use strict';
const puppeteer = require('puppeteer');
// const { Builder, By, Key, Capabilities, until, Select, Actions, WebDriver } = require('selenium-webdriver');
// const chrome = require('selenium-webdriver/chrome');
// const edge = require('selenium-webdriver/edge');
// const chromedriver = require('chromedriver');
// const edgedriver = require('edgedriver');
// const decompress = require('decompress');
const Source = require('../../provider/source');
let config = {}
const driversDict = {}
const { DriverInterface } = require('../../interface/driver_interface');


const Page = require('./modus/page')
const Handle = require('./modus/handle')
const Download = require('./modus/download')
const Screen = require('./modus/screen')
const Content = require('./modus/content');
const Util = require('../../provider/util');

class PuppeteerDriver extends DriverInterface {

    setConfig(conf = {}) {
        config = conf
    }


    async documentInitialised() {
        const driver = this.getDriver();
        const outerHTML = await driver.executeScript("return document.documentElement.outerHTML");
        if (outerHTML != null && outerHTML.length > 0) {
            console.log(`outerHTML${outerHTML.length}`);
        }
        return driver;
    }

    async printDriverParameters(driverType) {
        let parameterNames = "";
        if (driverType === 'chrome') {
            parameterNames = this.comUtil.getParameter(chrome.Driver);
        } else if (driverType === 'edge') {
            parameterNames = this.comUtil.getParameter(edge.Driver);
        }
        console.log(`\tdriver_parameter:${parameterNames}`);
    }

    async createChromeDriver(options = {}) {
        let {
            openDevtools = false,
            mobile = false,
            disableGpu = true,
            proxy = null,
            waitForComplete = true,
            logging = false,
            userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            mute = false,
            showImages = true
        } = options
        
        let width, height, pixelRatio;
        const chromeCapabilities = webdriver.Capabilities.chrome();
        const chromeOptions = new chrome.Options();
        
        if (openDevtools) {
            chromeOptions.addArguments('--auto-open-devtools-for-tabs');
        }
        
        if (mobile) {
            width = 320;
            height = 568;
            pixelRatio = 2.0;
            const mobileEmulation = {
                deviceName: 'iPhone SE',
                deviceMetrics: {
                    width: width,
                    height: height,
                    pixelRatio: pixelRatio,
                },
                userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0 Mobile/15E148 Safari/604.1',
            };
            chromeOptions.setMobileEmulation(mobileEmulation);
        }
        
        if (disableGpu) {
            chromeOptions.addArguments('--disable-gpu');
            if (!showImages) {
                chromeOptions.addArguments('--blink-settings=imagesEnabled=false');
            }
        }
        
        if (mute) {
            chromeOptions.addArguments('--mute-audio');
        }
        
        if (proxy) {
            const browsermobProxy = this.comConfig.getPublic('libs/browsermob-proxy-2.1.4/bin/browsermob-proxy');
            this.__browsermobProxy = true;
            if (Util.isWindows()) {
                browsermobProxy += '.bat';
            }
            const server = require('browsermob-proxy').Server;
            const proxyServer = new server({
                path: browsermobProxy,
            });
            proxyServer.start();
            this.proxy = proxyServer.createProxy();
            const proxyArgument = `--proxy-server=${this.proxy.proxy}`;
            chromeOptions.addArguments(proxyArgument);
        }
        
        if (!waitForComplete) {
            chromeCapabilities.set('pageLoadStrategy', 'none');
            chromeOptions.setPageLoadStrategy('none');
        }
        
        if (logging) {
            chromeCapabilities.set('loggingPrefs', {
                browser: 'ALL',
                performance: 'ALL',
            });
        }
        
        chromeOptions.addArguments(`--user-agent=${userAgent}`);
        
        chromeCapabilities.set('goog:chromeOptions', {
            perfLoggingPrefs: {
                enableNetwork: true,
            },
            w3c: false,
        });
        
        const driver = new Builder()
            .forBrowser('chrome')
            .withCapabilities(chromeCapabilities)
            .setChromeOptions(chromeOptions)
            .usingServer(chromedriver.path)
            .build();
        
        return driver;
    }

    async loadJQuery() {
        console.log('load_JQuery');
        // 这里可以添加加载 jQuery 的逻辑，以确保页面中已加载 jQuery
        // 如果您有 jQuery 文件，可以注入它，或者使用其他方法来确保 jQuery 可用。
        // 这里假设 jQuery 已经加载，因此没有添加具体的加载逻辑。
        return true;
    }

    async loadJQueryWait(loadDeep = 0) {
        if (loadDeep === 3) {
            console.log(`load_JQuery_wait loadDeep ${loadDeep}`);
            return false;
        }

        const driver = await new Builder().forBrowser('chrome').build();
        console.log('load_JQuery_wait');

        try {
            const jQueryString = await driver.executeScript("return jQuery.toString()");
            console.log(jQueryString);
            return true;
        } catch (error) {
            console.error(error);
            await new Promise(resolve => setTimeout(resolve, 1500)); // 等待1.5秒
            loadDeep += 1;
            await loadJQuery();
            return await loadJQueryWait(loadDeep);
        } finally {
            await driver.quit();
        }
    }



    async setBrowser() {
        let prefs = {
            'profile.managed_default_content_settings.images': 1,
        };

        if (this.flashUrls && this.flashUrls.length > 0) {
            prefs['profile.managed_plugins_allowed_for_urls'] = this.flashUrls;
        }

        this.options.setChromeOptions(this.options);
        this.options.setUserPreferences(prefs);
        this.options.setExperimentalOption('w3c', false);

        logging.installConsoleHandler();

        const driver = await new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .setLoggingPrefs({ 'performance': 'ALL' })
            .build();

        return driver;
    }

}

PuppeteerDriver.toString = () => '[class PuppeteerDriver]';
module.exports = PuppeteerDriver;

